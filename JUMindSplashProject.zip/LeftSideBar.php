  <div class="shortcuts">
            <div class="first-col">
                <div class="menu-item">
                    <div class="user" data-toggle="modal" data-target="#UserInfo">
                        <div class="profile">
                            <img src="<?= $_SESSION['Image'] ?>" alt="">
                        </div>
                        <h4><?= $_SESSION['Name'] ?></h4>
                    </div>
                </div>



                <div class="menu-item">
                    <a href="Users.php" class="item-row">
                        <div class="icon">
                            <img src="img/icons/colored-people.svg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['User'];?> </h4>
                    </a>
                </div>



                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/icons/magnifier-690.svg" style="width: 25px; height: 25px;" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['ResearchRequest'];?> </h4>
                    </div>
                </div>

            </div>

            <div class="second-col" id="category">

                <h6 class="title">
                    <?php echo $text[$lang]['Colleges'];?>
                </h6>



            </div>
        </div>