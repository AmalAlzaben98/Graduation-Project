<?php
$pageName= basename($_SERVER['PHP_SELF']);

?>
<nav>
        <!--logo and search-->
        <div class="left-side">
            <div class="logo">
                <img src="img/logo-mind.png" alt="">
            </div>

            <div class="search">
                <input type="text" placeholder="Search in JU mind splash" name="" id="">
            </div>
        </div>

        <!--tab icons-->
        <div class="tabs">
            <a href="index.php" class="tab-icon <?= $pageName=="index.php"?"active":"" ?> ">
                <div class="icon">
                    <img src="img/icons/home-button-for-interface.svg" alt="">
                </div>
            </a>

            <div class="tab-icon">
                <div class="icon <?= $pageName=="index.php"?"active":"" ?>">
                    <img src="img/icons/flag.svg" alt="">
                </div>
            </div>
            <a href="Research.php" class="tab-icon <?= $pageName=="Research.php"?"active":"" ?>">
                <div class="icon">
                    <img src="img/icons/research.svg" alt="">
                </div>
            </a>
            <a href="Event.php" class="tab-icon  <?= $pageName=="Event.php"?"active":"" ?>">
                <div class="icon">
                    <img src="img/icons/calendar.svg" alt="">
                </div>
            </a>
        </div>

        <!--right side-->
        <div class="right-side">
            <div class="user"  data-toggle="modal" data-target="#UserInfo">
                <div class="profile">
                    <img src="<?= $_SESSION['Image'] ?>" alt="">
                </div>
                <h4><?= $_SESSION['Name'] ?></h4>
            </div>

            <!--icons-->
            <div class="user-icons">



<div class="dropdown">
 <div class="icon" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                    <img src="img/icons/arrow.svg" alt="" >
                </div>
  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
    <li><div class="dropdown-item ChangeLang" href="#"> <?= $lang=="En"?"العربية":"English"?></div></li>
    <li><a class="dropdown-item " href="#"> <?php echo $text[$lang]['Logout'];?></a></li>
  </ul>
</div>
            </div>
        </div>
    </nav>




