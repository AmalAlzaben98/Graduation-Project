
<?php

$text ['Ar']['User'] = "المستخدمون";
$text ['En']['User'] = "Users";

$text ['Ar']['ResearchRequest'] = "طلبات البحث";
$text ['En']['ResearchRequest'] = "Research Requests";

$text ['Ar']['AddNewEvent'] = "أضف حدث جديد";
$text ['En']['AddNewEvent'] = "Add New Event";

$text ['Ar']['EventDescription'] = "وصف الحدث";
$text ['En']['EventDescription'] = "Event Description";

$text ['Ar']['EventName'] = "اسم الحدث";
$text ['En']['EventName'] = "Event Name";

$text ['Ar']['UserInfo'] = "معلومات المستخدم";
$text ['En']['UserInfo'] = "User Info";

$text ['Ar']['EventTime'] = "وقت الحدث";
$text ['En']['EventTime'] = "Event Time";

$text ['Ar']['Join'] = "انضم";
$text ['En']['Join'] = "Join";

$text ['Ar']['Left'] = "غادر";
$text ['En']['Left'] = "Left";



$text ['Ar']['seemore'] = "شاهد المزيد";
$text ['En']['seemore'] = "see more";

$text ['Ar']['Colleges'] = "الكليات";
$text ['En']['Colleges'] = "Colleges";

$text ['Ar']['CollegesPost'] = "النشر في  كلية";
$text ['En']['CollegesPost'] = "Post in college";

$text ['Ar']['Post'] = "منشور";
$text ['En']['Post'] = "Post";

$text ['Ar']['Research'] = "بحث";
$text ['En']['Research'] = "Research";

$text ['Ar']['Event'] = "حدث";
$text ['En']['Event'] = "Event";


$text ['Ar']['Yourpages'] = "صفحاتك";
$text ['En']['Yourpages'] = "Your pages";


$text ['Ar']['Rateus'] = "قيم الآن";
$text ['En']['Rateus'] = "Rate now";

$text ['Ar']['Rateresearch'] = "قيم البحث";
$text ['En']['Rateresearch'] = "Rate research";


$text ['Ar']['addImage'] = "إضافة صورة";
$text ['En']['addImage'] = "Add Image";

$text ['Ar']['addFile'] = "إضافة ملف";
$text ['En']['addFile'] = "Add File";

$text ['Ar']['publish'] = "نشر";
$text ['En']['publish'] = "Publish";

$text ['Ar']['writeacomment'] = "أكتب تعليقا";
$text ['En']['writeacomment'] = "Write a comment";

$text ['Ar']['ago'] = "منذ";
$text ['En']['ago'] = "ago";

$text ['Ar']['hour'] = "ساعة";
$text ['En']['hour'] = "hour";

$text ['Ar']['like'] = "اعجبني";
$text ['En']['like'] = "Like";


$text ['Ar']['comment'] = "التعلقيات";
$text ['En']['comment'] = "Comment";

$text ['Ar']['share'] = "مشاركة";
$text ['En']['share'] = "Share";

$text ['Ar']['Logout'] = "تسجيل  الخروج";
$text ['En']['Logout'] = "Logout";
