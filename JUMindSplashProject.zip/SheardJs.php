<div class="modal fade" style="background-color: #000000bd;" id="ModalPostorNews" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialogmargin" role="document">
    <div class="modal-content"  style="background-color: unset;"
    >

      <div class="modal-body modal-bodycustome">
      	<div class="container">
                <div class="row">
                    <div class="col-md-6 t-c">
                    <a href="" id="gotopost">
                                     <img style="width: 70%;    margin-bottom: 20px;"src="img/icons/social-media-announcement-45482.svg" alt="">
                                     <br>
                                     <span class="m-t"> <?php echo $text[$lang]['Post'];?></span>
</a>
 					</div>
 					<div class="col-md-6 t-c">
 					 <a href="" id="gotoresearch">
								<img style="width: 70%;margin-bottom: 20px;" src="img/icons/research-6892.svg" alt="">
								<br>
								<span class="m-t"> <?php echo $text[$lang]['Research'];?></span>
 					</a>
 					</div>
 					</div>
            </div>

      </div>

    </div>
  </div>
</div>
<div class="modal fade" style="background-color: #000000bd;" id="UserInfo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialogmargin" role="document" style="max-width: 700px;margin-top: 50px;">
    <div class="modal-content"  style="background-color: unset;text-align: center;"
    >

      <div class="modal-body modal-bodycustome" >
      	<div class="container">
                <div class="row">
					<h4><?php echo $text[$lang]['UserInfo'];?></h4>
					<div class="col-md-12">
						<img class="userInfoImages" src="<?= $_SESSION['Image'] ?>" alt="" />
					</div>
					<div class="row" style="margin-top: 20px;">
						<div class="col-md-12 d-flex">
         				  <div class="col-md-6">
                             <input type="text" class="userFornInput" value="<?= $_SESSION['Fname'] ?>" name="username" id="Fname" class="name">

                          </div>



                          <div class="col-md-6">
                             <input type="text" class="userFornInput" value="<?= $_SESSION['Lname'] ?>" name="username" id="Lname" class="name">

                          </div>







						</div>
					</div>
<div class="row" style="margin-top: 20px;">
						<div class="col-md-12 d-flex">
						 <div class="col-md-6">
                             <input type="text" class="userFornInput" placeholder="Password" name="username" id="Fname" class="name">

                          </div>



                          <div class="col-md-6">
                             <input type="text" class="userFornInput" placeholder="Confirm Password"  name="username" id="Lname" class="name">

                          </div>
						</div></div>

						                            <input type="file"
       id="userImageInput" name="avatar"
       accept="image/png, image/jpeg" style="display: none;">
 				</div>
            </div>

      </div>

    </div>
  </div>
</div>
<script>
var lang= $("html").attr("lang")
$(".userInfoImages").click(()=>{
	$("#userImageInput").click();

});
$("#userImageInput").change(function(e){
    var file = e.target.files[0];
    var reader = new FileReader();
             reader.readAsDataURL(file); //read base64
    reader.onloadend = function () {
                     // The base64 value of the image
        data_64= reader.result.substring(reader.result.indexOf(",")+1);
        $(".userInfoImages").attr("src",reader.result);
        $.ajax({
    		  method: "POST",
    	      url: "backend/server.php",
    		  data: {
    			  action   : "UpdateUserImage",
    			  Image:reader.result
    		  	}

    		})

            };
});

$(".ChangeLang").click(()=>{


	  $.ajax({
		  method: "POST",
	      url: "setLang.php",
		  data: {
			  action   : "ChangeLang"
		  	}

		}).done(function( data ) {


			location.reload()
			});


	})
$.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "getِAllCategory"
		  	}

		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 for(var i=0;i<jsonObj.length;i++){
	               var item='<div class="menu-item">'
                    +'<div class="item-row" onclick="changActiron('+jsonObj[i].CategoryID+')">'
                    +'<div class="icon">'
                    +'<img src="'+jsonObj[i].CategoryImage+'" alt="">'
                    +'</div>'
                    +'<h4 style="width: 200px">'+jsonObj[i]['CategoryName'+lang]+'</h4>'
                    +'</div>'
                    +'</div>'
				 $("#category").append(item);
	               $("#CollegesListSelect").append('<option value="'+jsonObj[i].CategoryID+'">'+jsonObj[i]['CategoryName'+lang]+'</option>');
	               $("#CollegesListSelect2").append('<option value="'+jsonObj[i].CategoryID+'">'+jsonObj[i]['CategoryName'+lang]+'</option>');

			 }


		});
function changActiron(id){
	$("#gotoresearch").attr("href","Research.php?id="+id)
		$("#gotopost ").attr("href","index.php?id="+id)
	$("#ModalPostorNews").modal('show');
}
</script>