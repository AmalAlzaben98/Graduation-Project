<div class="modal fade" style="background-color: #000000bd;" id="addnewEvent" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog " role="document">
    <div class="modal-content"  style="background-color: unset;"
    >

      <div class="modal-body " >
   <!--create post-->
   <div class="posts" style=" width: 100%; height: 198px; ">
            <div class="timeline">
                <div class="view create-post">
                <h3 style="text-align: center; color: white; margin-bottom: 22px;">
                <?php echo $text[$lang]['AddNewEvent'];?>
                </h3>

                    <div class="input">

<input type="text" style="margin-left: unset; border-radius: unset; margin-bottom: 12px;" id="EventName" placeholder="<?php echo $text[$lang]['EventName'];?>" />
                    </div>

 <div class="input">

<input type="text" id="datetimepicker1" style="margin-left: unset; border-radius: unset; margin-bottom: 12px;" placeholder="<?php echo $text[$lang]['EventTime'];?>" />
                    </div>
                    <div class="input">

<textarea id="postDescription" name="w3review" rows="4" placeholder="<?php echo $text[$lang]['EventDescription'];?>" class="textAreaUi"cols="50">
</textarea>
                    </div>


                    <div class="post-img">
                            <img class="post-img-add" id="imagebase64Post" src="" alt="">
                        </div>
                    <div class="media">
                        <div class="category">
                            <div class="option pointer-c" id="openFile">
                                <div class="icon">
                                    <img src="img/icons/add.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['addImage'];?></span>

                            </div>
							<div class="publisbutn" id="publisbutn">
                                <?php echo $text[$lang]['publish'];?>
                            </div>
                            <input type="file"
       id="postImageInput" name="avatar"
       accept="image/png, image/jpeg" style="display: none;">

                        </div>
                    </div>
                </div>
                </div>
</div>
      </div>

    </div>
  </div>
</div>


<script type="text/javascript">

var lang= $("html").attr("lang")
$(document).ready(function () {
	$(function () {
        $('#datetimepicker1').datetimepicker();
    });
	  $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "getِAllEvent",
		  	}

		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 for(var i=0;i<jsonObj.length;i++){
				 var obj = jsonObj[i]
				 var name=obj.Fname+" "+obj.Lname;
				 var haveUserLike;
				 if(Array.isArray(obj.EventRoll) && obj.EventRoll.length){
					 haveUserLike="<?php echo $text[$lang]["Left"];?>";
					 }else{

					 haveUserLike="<?php echo $text[$lang]["Join"];?>";
					 }
				 appendPost(obj.CreateAt,obj.Image,name,obj.EventDescription,obj.EventID,obj.EventImage,haveUserLike,obj.EventTime);
			 }


		});




$("#openFile").click(()=>{
	$("#postImageInput").click();
});
$("#postImageInput").change(function(e){
    var file = e.target.files[0];
    var reader = new FileReader();
             reader.readAsDataURL(file); //read base64
    reader.onloadend = function () {
                     // The base64 value of the image
        data_64= reader.result.substring(reader.result.indexOf(",")+1);
        $("#imagebase64Post").attr("src",reader.result);
        $(".post-img-add").css("display","flex");


            };
});

$("#publisbutn").click(()=>{
	 $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "addNewEvent",
			  EventTime:$("#datetimepicker1").val(),
			  EventImage:$("#imagebase64Post").attr("src"),
			  EventName:$("#EventName").val(),
			  EventDescription:$("#postDescription").val()
		  	}
		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 if(jsonObj.status=="success")
				{
				 location.reload();
				}
		});

});

$('.Writeacomment').keypress(function (e) {
	 var key = e.which;
	 if(key == 13)  // the enter key code
	  {
	   if($(this).val()!="")
	   {

		   var bostID=$(this).attr("bostID")
		   $.ajax({
				  method: "POST",
			      url: "backend/server.php",
				  data: {
					  action   : "addPostComment",
					  PostID:bostID,
					  Comment:$(this).val()
				  	}
				}).done(function( data ) {
					 var jsonObj = JSON.parse(data);
					 console.log(jsonObj);
						 var obj = jsonObj[0]
						 var Comment="";


						 Comment='<div class="d-flex" style="  width: 100%;margin-top: 7px;">'
		                    +'<div class="user">'
		                    +'<div class="profile"><img src="'+obj.Image+'" alt=""></div>'
		                    +'</div>'
		                    +'<div class="info" style="width: 100%; background-color: #1a4464; color: white; padding: 3px 7px; border-radius: 5px;">'
		                    +'<h6 class="name">'+obj.Fname+" "+obj.Lname+'</h6>'
		                    +'<p>'
							+obj.Comment
		                    +'</p>'
		                    +'<span class="time">1 hour ago</span>'
		                    +'</div>'
		                    +'</div>';
							$("#listcomment").prepend(Comment);

							$(".Writeacomment").val("")

				});

		}
	  }
	});
});


function appendPost(CreateAt,image,name,PostDescription,PostID,PostImage,haveUserLike,EventTime){
	var like="<?php echo $text[$lang]["Join"];?>";
	var comment="<?php echo $text[$lang]["comment"];?>";
	var share="<?php echo $text[$lang]["share"];?>";
	var writeacomment="<?php echo $text[$lang]["writeacomment"];?>";
	var ago="<?php echo $text[$lang]["ago"];?>";
	var hour="<?php echo $text[$lang]["hour"];?>";


	  var date1 = new Date(CreateAt);
		const d = new Date();

	  console.log(date1.getMinutes());



	var post="";
	post='<div class="view view-post-container smaller-margin">'
    +'<div class="view-post">'
    +'<div class="upper">'
    +'<div class="d-flex">'
    +'<div class="user">'
    +'<div class="profile">'
    +'<img src="'+image+'" alt="">'
    +'</div>'
    +'</div>'

    +'<div class="info">'
    +'<h6 class="name">'
    +name
    +'</h6>'
    +'</div>'
    +'</div>'
    +'</div>'

    +'<div class="desc">'
    +'<p>'+PostDescription+'</p>'
	+'</div>'
	if(PostImage!=""){
		post+='<div class="post-img" style="height: 61vh;position: relative;">'
	+'<img src="'+PostImage+'" alt="">'
	+'<div class="JointToEvent">'
	+'<div class="EventTime" >'+EventTime+'</div>'
	+'<div class="EventJoin" id="EventJoin'+PostID+'" onclick="EventJoin('+PostID+')">'+haveUserLike+'</div>'

	+'</div>'
	+'</div>'
	}


	+'</div>'
	+'</div>';
	$("#Postcontainer").prepend(post);
}
function openComment(PostID){

	  $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "getCommentPost",
			  PostID:PostID
		  	}
		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 $("#listcomment").empty();
			 console.log(jsonObj);
			 for(var i=0;i<jsonObj.length;i++){
				 var obj = jsonObj[i]
				 var Comment="";


				 Comment='<div class="d-flex" style="  width: 100%;margin-top: 7px;">'
                    +'<div class="user">'
                    +'<div class="profile"><img src="'+obj.Image+'" alt=""></div>'
                    +'</div>'
                    +'<div class="info" style="width: 100%; background-color: #1a4464; color: white; padding: 3px 7px; border-radius: 5px;">'
                    +'<h6 class="name">'+obj.Fname+" "+obj.Lname+'</h6>'
                    +'<p>'
					+obj.Comment
                    +'</p>'
                    +'<span class="time">1 hour ago</span>'
                    +'</div>'
                    +'</div>';
					$("#listcomment").prepend(Comment);
			 }


		});

		$("#Writeacomment").attr('bostID',PostID);
	$("#ModalPostorComments").modal('show');

}
function ChangeLike(PostID){
	var srcLike=$("#LikeID"+PostID).attr("src");
	if(srcLike=="img/icons/thumbs-up2.svg"){
		$("#LikeID"+PostID).attr("src","img/icons/thumbs-up.svg");
		 $.ajax({
			  method: "POST",
		      url: "backend/server.php",
			  data: {
				  action   : "deletePostLike",
				  PostID:PostID
			  	}
			})


		}else{
			$("#LikeID"+PostID).attr("src","img/icons/thumbs-up2.svg");
			 $.ajax({
				  method: "POST",
			      url: "backend/server.php",
				  data: {
					  action   : "addPostLike",
					  PostID:PostID
				  	}
				})
			}
}
function EventJoin(PostID){
	var Join="<?php echo $text[$lang]["Join"];?>";
	var Left="<?php echo $text[$lang]["Left"];?>";

	 $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "ChangeEventJoin",
			  EventID:PostID
		  	}
		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			if(jsonObj.msg=="Join"){
				$("#EventJoin"+PostID).text(Join)
				}else{
					$("#EventJoin"+PostID).text(Left)
					}

			 });

}

</script>
