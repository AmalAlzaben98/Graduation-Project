<script type="text/javascript">
var lang= $("html").attr("lang")
$(document).ready(function () {
	  $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "getCategoryPost",
			  CategoryID:9
		  	}

		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 for(var i=0;i<jsonObj.length;i++){
				 var obj = jsonObj[i]
				 var name=obj.Fname+" "+obj.Lname
				 appendPost(obj.CreateAt,obj.Image,name,obj.PostDescription,obj.PostID,obj.PostImage);
			 }


		});
	  $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "getِAllCategory"
		  	}

		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 for(var i=0;i<jsonObj.length;i++){
	               var item='<div class="menu-item">'
                    +'<div class="item-row" onclick="changActiron('+jsonObj[i].CategoryID+')">'
                    +'<div class="icon">'
                    +'<img src="'+jsonObj[i].CategoryImage+'" alt="">'
                    +'</div>'
                    +'<h4 style="width: 200px">'+jsonObj[i]['CategoryName'+lang]+'</h4>'
                    +'</div>'
                    +'</div>'
				 $("#category").append(item);
	               $("#CollegesListSelect").append('<option value="'+jsonObj[i].CategoryID+'">'+jsonObj[i]['CategoryName'+lang]+'</option>');

			 }


		});
    //story slider
    $(".slider").owlCarousel({
        loop: true,
        margin: 10,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        smartSpeed: 1000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 5
            }
        }
    });

    var owl = $(".slider");
    owl.owlCarousel();
    // Go to the next item
    $(".nxtBtn").click(function () {
        owl.trigger("next.owl.carousel");
    });





    $(".rooms").owlCarousel({
        loop: true,
        margin: 5,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        smartSpeed: 1000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 10
            }
        }
    });




    $(".people").owlCarousel({
        loop: true,
        margin: 5,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        smartSpeed: 1000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3.5
            }
        }
    });

$("#openFile").click(()=>{
	$("#postImageInput").click();
});
$("#postImageInput").change(function(e){
    var file = e.target.files[0];
    var reader = new FileReader();
             reader.readAsDataURL(file); //read base64
    reader.onloadend = function () {
                     // The base64 value of the image
        data_64= reader.result.substring(reader.result.indexOf(",")+1);
        $("#imagebase64Post").attr("src",reader.result);
        $(".post-img-add").css("display","flex");


            };
});

$("#publisbutn").click(()=>{
	 $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "addNewPost",
			  PostDescription:$("#postDescription").val(),
			  PostImage:$("#imagebase64Post").attr("src"),
			  CategoryID:$("#CollegesListSelect").val()
		  	}
		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 if(jsonObj.status=="success")
				{
				 location.reload();
				}
		});

});
});

function changActiron(id){
	$("#gotoresearch").attr("href","Research.php?id="+id)
		$("#gotopost ").attr("href","Post.php?id="+id)
	$("#ModalPostorNews").modal('show');
}
function appendPost(CreateAt,image,name,PostDescription,PostID,PostImage){

	var post="";
	post='<div class="view view-post-container smaller-margin">'
    +'<div class="view-post">'
    +'<div class="upper">'
    +'<div class="d-flex">'
    +'<div class="user">'
    +'<div class="profile">'
    +'<img src="'+image+'" alt="">'
    +'</div>'
    +'</div>'

    +'<div class="info">'
    +'<h6 class="name">'
    +name
    +'</h6>'
    +'<span class="time">1 hour ago</span>'
    +'</div>'
    +'</div>'

    +'<div class="dots">'
    +'<div class="dot"></div>'
    +'</div>'
    +'</div>'

    +'<div class="desc">'
    +'<p>'+PostDescription+'</p>'
	+'</div>'
	if(PostImage!=""){
		post+='<div class="post-img">'
	+'<img src="'+PostImage+'" alt="">'
	+'</div>'
	}
	post+='<div class="actions-container">'
	+'<div class="action">'
	+'<div class="icon">'
	+'<img src="img/icons/thumbs-up.svg" alt="">'
	+'</div>'
	+'<span>'
	+'like'
	+'</span>'
	+'</div>'
	+'<div class="action">'
	+'<div class="icon">'
	+'<img src="img/icons/comment.svg" alt="">'
	+' </div>'
	+'<span>'
	+ <?php echo $text[$lang]['Post'];?>
	+'</span>'
	+'</div>'
	+'<div class="action">'
	+'<div class="icon">'
	+'<img src="img/icons/share.svg" alt="">'
	+'</div>'
	+'<span>'
	+'share'
	+'</span>'
	+'</div>'
	+'</div>'
	+'<div class="write-comment">'
	+'<div class="user">'
	+'<div class="profile">'
	+'<img src="img/avatar/hero.png" alt="">'
	+'</div>'
	+'</div>'
	+'<div class="input">'
	+'<input type="text" placeholder="Write a comment" name="" id="">'
	+'</div>'
	+'</div>'
	+'</div>'
	+'</div>';
	$(".Postcontainer").prepend(post);
}

</script>
