<div class="modal fade" style="background-color: #000000bd;" id="addnewpost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog " role="document">
    <div class="modal-content"  style="background-color: unset;"
    >

      <div class="modal-body " >
   <!--create post-->
   <div class="posts" style=" width: 100%; height: 198px; ">
            <div class="timeline">
                <div class="view create-post">
                <label  class="customelable" for="cars"><?php echo $text[$lang]['CollegesPost'];?></label>

<select name="CollegesListSelect" class="custom-select" style="width:200px;" id="CollegesListSelect">

</select>
                    <div class="input">

<textarea id="postDescription" name="w3review" rows="4"  class="textAreaUi"cols="50">
</textarea>
                    </div>
                    <div class="post-img">
                            <img class="post-img-add" id="imagebase64Post" src="" alt="">
                        </div>
                    <div class="media">
                        <div class="category">
                            <div class="option pointer-c" id="openFile">
                                <div class="icon">
                                    <img src="img/icons/add.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['addImage'];?></span>

                            </div>
							<div class="publisbutn" id="publisbutn">
                                <?php echo $text[$lang]['publish'];?>
                            </div>
                            <input type="file"
       id="postImageInput" name="avatar"
       accept="image/png, image/jpeg" style="display: none;">

                        </div>
                    </div>
                </div>
                </div>
</div>
      </div>

    </div>
  </div>
</div>


<script type="text/javascript">

var lang= $("html").attr("lang")
$(document).ready(function () {
	  $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "getCategoryPost",
			  CategoryID:<?= $_GET['id'] !=""?$_GET['id']:$_SESSION['CategoryID'] ?>
		  	}

		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 for(var i=0;i<jsonObj.length;i++){
				 var obj = jsonObj[i]
				 var name=obj.Fname+" "+obj.Lname;
				 var haveUserLike;
				 if(Array.isArray(obj.haveLike) && obj.haveLike.length){
					 haveUserLike="2";
					 }else{
					 haveUserLike="";
					 }
				 appendPost(obj.CreateAt,obj.Image,name,obj.PostDescription,obj.PostID,obj.PostImage,haveUserLike);
			 }


		});

    //story slider
    $(".slider").owlCarousel({
        loop: true,
        margin: 10,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        smartSpeed: 1000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 5
            }
        }
    });

    var owl = $(".slider");
    owl.owlCarousel();
    // Go to the next item
    $(".nxtBtn").click(function () {
        owl.trigger("next.owl.carousel");
    });





    $(".rooms").owlCarousel({
        loop: true,
        margin: 5,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        smartSpeed: 1000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 10
            }
        }
    });




    $(".people").owlCarousel({
        loop: true,
        margin: 5,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        smartSpeed: 1000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 1
            },
            1000: {
                items: 3.5
            }
        }
    });

$("#openFile").click(()=>{
	$("#postImageInput").click();
});
$("#postImageInput").change(function(e){
    var file = e.target.files[0];
    var reader = new FileReader();
             reader.readAsDataURL(file); //read base64
    reader.onloadend = function () {
                     // The base64 value of the image
        data_64= reader.result.substring(reader.result.indexOf(",")+1);
        $("#imagebase64Post").attr("src",reader.result);
        $(".post-img-add").css("display","flex");


            };
});

$("#publisbutn").click(()=>{
	 $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "addNewPost",
			  PostDescription:$("#postDescription").val(),
			  PostImage:$("#imagebase64Post").attr("src"),
			  CategoryID:$("#CollegesListSelect").val()
		  	}
		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 console.log(jsonObj);
			 if(jsonObj.status=="success")
				{
				 location.reload();
				}
		});

});

$('.Writeacomment').keypress(function (e) {
	 var key = e.which;
	 if(key == 13)  // the enter key code
	  {
	   if($(this).val()!="")
	   {

		   var bostID=$(this).attr("bostID")
		   $.ajax({
				  method: "POST",
			      url: "backend/server.php",
				  data: {
					  action   : "addPostComment",
					  PostID:bostID,
					  Comment:$(this).val()
				  	}
				}).done(function( data ) {
					 var jsonObj = JSON.parse(data);
					 console.log(jsonObj);
						 var obj = jsonObj[0]
						 var Comment="";


						 Comment='<div class="d-flex" style="  width: 100%;margin-top: 7px;">'
		                    +'<div class="user">'
		                    +'<div class="profile"><img src="'+obj.Image+'" alt=""></div>'
		                    +'</div>'
		                    +'<div class="info" style="width: 100%; background-color: #1a4464; color: white; padding: 3px 7px; border-radius: 5px;">'
		                    +'<h6 class="name">'+obj.Fname+" "+obj.Lname+'</h6>'
		                    +'<p>'
							+obj.Comment
		                    +'</p>'
		                    +'<span class="time">1 hour ago</span>'
		                    +'</div>'
		                    +'</div>';
							$("#listcomment").prepend(Comment);

							$(".Writeacomment").val("")

				});

		}
	  }
	});
});


function appendPost(CreateAt,image,name,PostDescription,PostID,PostImage,haveUserLike){
	var like="<?php echo $text[$lang]["like"];?>";
	var comment="<?php echo $text[$lang]["comment"];?>";
	var share="<?php echo $text[$lang]["share"];?>";
	var writeacomment="<?php echo $text[$lang]["writeacomment"];?>";
	var ago="<?php echo $text[$lang]["ago"];?>";
	var hour="<?php echo $text[$lang]["hour"];?>";
	var images="<?= $_SESSION['Image'] ?>";

	  var date1 = new Date(CreateAt);
		const d = new Date();

	  console.log(date1.getMinutes());



	var post="";
	post='<div class="view view-post-container smaller-margin">'
    +'<div class="view-post">'
    +'<div class="upper">'
    +'<div class="d-flex">'
    +'<div class="user">'
    +'<div class="profile">'
    +'<img src="'+image+'" alt="">'
    +'</div>'
    +'</div>'

    +'<div class="info">'
    +'<h6 class="name">'
    +name
    +'</h6>'
    +'</div>'
    +'</div>'
    +'</div>'

    +'<div class="desc">'
    +'<p>'+PostDescription+'</p>'
	+'</div>'
	if(PostImage!=""){
		post+='<div class="post-img">'
	+'<img src="'+PostImage+'" alt="">'
	+'</div>'
	}
	post+='<div class="actions-container" onclick="ChangeLike('+PostID+')">'
	+'<div class="action">'
	+'<div class="icon">'
	+'<img id="LikeID'+PostID+'" src="img/icons/thumbs-up'+haveUserLike+'.svg" alt="">'
	+'</div>'
	+'<span>'
	+like
	+'</span>'
	+'</div>'
	+'<div class="action" onclick="openComment('+PostID+')">'
	+'<div class="icon">'
	+'<img src="img/icons/comment.svg" alt="">'
	+' </div>'
	+'<span>'
	+ comment
	+'</span>'
	+'</div>'
	+'<div class="action">'
	+'<div class="icon">'
	+'<img src="img/icons/share.svg" alt="">'
	+'</div>'
	+'<span>'
	+share
	+'</span>'
	+'</div>'
	+'</div>'
	+'<div class="write-comment">'
	+'<div class="user">'
	+'<div class="profile">'
	+'<img src="'+images+'" alt="">'
	+'</div>'
	+'</div>'
	+'<div class="input">'
	+'<input type="text" bostID="'+PostID+'"  class="Writeacomment" placeholder="'+writeacomment+'" name="" id="">'
	+'</div>'
	+'</div>'
	+'</div>'
	+'</div>';
	$("#Postcontainer").prepend(post);
}
function openComment(PostID){

	  $.ajax({
		  method: "POST",
	      url: "backend/server.php",
		  data: {
			  action   : "getCommentPost",
			  PostID:PostID
		  	}
		}).done(function( data ) {
			 var jsonObj = JSON.parse(data);
			 $("#listcomment").empty();
			 console.log(jsonObj);
			 for(var i=0;i<jsonObj.length;i++){
				 var obj = jsonObj[i]
				 var Comment="";


				 Comment='<div class="d-flex" style="  width: 100%;margin-top: 7px;">'
                    +'<div class="user">'
                    +'<div class="profile"><img src="'+obj.Image+'" alt=""></div>'
                    +'</div>'
                    +'<div class="info" style="width: 100%; background-color: #1a4464; color: white; padding: 3px 7px; border-radius: 5px;">'
                    +'<h6 class="name">'+obj.Fname+" "+obj.Lname+'</h6>'
                    +'<p>'
					+obj.Comment
                    +'</p>'
                    +'<span class="time">1 hour ago</span>'
                    +'</div>'
                    +'</div>';
					$("#listcomment").prepend(Comment);
			 }


		});

		$("#Writeacomment").attr('bostID',PostID);
	$("#ModalPostorComments").modal('show');

}
function ChangeLike(PostID){
	var srcLike=$("#LikeID"+PostID).attr("src");
	if(srcLike=="img/icons/thumbs-up2.svg"){
		$("#LikeID"+PostID).attr("src","img/icons/thumbs-up.svg");
		 $.ajax({
			  method: "POST",
		      url: "backend/server.php",
			  data: {
				  action   : "deletePostLike",
				  PostID:PostID
			  	}
			})


		}else{
			$("#LikeID"+PostID).attr("src","img/icons/thumbs-up2.svg");
			 $.ajax({
				  method: "POST",
			      url: "backend/server.php",
				  data: {
					  action   : "addPostLike",
					  PostID:PostID
				  	}
				})
			}
}


</script>
