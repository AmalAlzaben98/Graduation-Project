<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>JU MIND SPLASH | Login</title>
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700|Raleway:300,600" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel="stylesheet" href="css/login.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="container">
   <section id="formHolder">

      <div class="row">

         <!-- Brand Box -->
         <div class="col-sm-6 brand">

            <div class="heading">
               <h2>JU Mind Splash</h2>
               <p>Your Right Choice</p>
            </div>

            <div class="success-msg">
               <p>Great! You are one of our members now</p>
               <a href="#" class="profile">Your Profile</a>
            </div>
         </div>


         <!-- Form Box -->
         <div class="col-sm-6 form">

            <!-- Login Form -->
            <div class="login form-peice ">
               <form class="login-form" action="#" method="post">
                  <div class="form-group">
                     <label for="loginemail">Email Adderss</label>
                     <input type="email" name="loginemail" id="loginemail" required>
                  </div>

                  <div class="form-group">
                     <label for="loginPassword">Password</label>
                     <input type="password" name="loginPassword" id="loginPassword" required>
                  </div>

                  <div class="CTA">
                     <input type="button" id="Login" value="Login">
                     <br />
                     <a href="#" class="switch">Don't have account ?</a>
                  </div>
               </form>
            </div><!-- End Login Form -->


            <!-- Signup Form -->
            <div class="signup form-peice switched">
               <form class="signup-form" action="#" method="post">
                   <div class="form-group" style="    display: flex;">
                                       <input type="radio" checked style="width: 15%;" id="html" name="fav_language" value="1">
<label for="html" class="labelO">Student</label>
<input type="radio"  style="    width: 15%;" id="css" name="fav_language" value="2">
<label for="css" class="labelO">Doctor</label>
                  </div>

                  <div class="form-group">
                     <label for="name">First Name</label>
                     <input type="text" name="username" id="Fname" class="name">

                  </div>



                  <div class="form-group">
                     <label for="name">Last Name</label>
                     <input type="text" name="username" id="Lname" class="name">

                  </div>

                  <div class="form-group">
                     <label for="email">Email Adderss</label>
                     <input type="email" name="emailAdress" id="email" class="email">

                  </div>




                  <div class="form-group">
                     <label for="password">Password</label>
                     <input type="password" name="password" id="password" class="pass">

                  </div>

                  <div class="form-group">
                     <label for="passwordCon">Confirm Password</label>
                     <input type="password" name="passwordCon" id="passwordCon" class="passConfirm">
                  </div>
<div class="form-group" style="margin-top: 8px;">
                     <label for="CollegesListSelect">College</label>

                     <select name="CollegesListSelect" class="custom-select" style="width: 100%; margin-top: 18px; color: black;" id="CollegesListSelect">

					</select>
                  </div>
                  <div class="CTA">
                     <input type="submit" value="Signup Now" id="submitSignup">
                     <a href="#" class="switch" id="switch">I have an account</a>
                  </div>
               </form>
            </div><!-- End Signup Form -->
         </div>
      </div>

   </section>




</div>
<!-- partial -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js'></script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js'></script>
<script  src="js/login.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$.ajax({
	  method: "POST",
  url: "backend/server.php",
	  data: {
		  action   : "getِAllCategory"
	  	}

	}).done(function( data ) {
		 var jsonObj = JSON.parse(data);
		 console.log(jsonObj);
		 for(var i=0;i<jsonObj.length;i++){
           $("#CollegesListSelect").append('<option value="'+jsonObj[i].CategoryID+'">'+jsonObj[i]['CategoryNameEn']+'</option>');

		 }


	});
	$("#submitSignup").click(()=>{


if($("#Fname").val()=="")
{

return 	Swal.fire({
	  position: 'bottom-end',
	  icon: 'error',
	  title: 'Your First Name required field',
	  showConfirmButton: false,
	  timer: 2000
	});

}
if($("#Lname").val()=="")
{

return 	Swal.fire({
	  position: 'bottom-end',
	  icon: 'error',
	  title: 'Your Last Name required field',
	  showConfirmButton: false,
	  timer: 2000
	});

}

if($("#email").val()=="")
{

return 	Swal.fire({
	  position: 'bottom-end',
	  icon: 'error',
	  title: 'Your Email Adderss required field',
	  showConfirmButton: false,
	  timer: 2000
	});

}
if(!validateEmail($("#email").val()))
{

return 	Swal.fire({
	  position: 'bottom-end',
	  icon: 'error',
	  title: 'Your Email Adderss Not valid',
	  showConfirmButton: false,
	  timer: 2000
	});

}

if($("#password").val()=="")
{

return 	Swal.fire({
	  position: 'bottom-end',
	  icon: 'error',
	  title: 'Your Password required',
	  showConfirmButton: false,
	  timer: 2000
	});

}

if($("#passwordCon").val()=="")
{

return 	Swal.fire({
	  position: 'bottom-end',
	  icon: 'error',
	  title: 'Your Confirm Password required',
	  showConfirmButton: false,
	  timer: 2000
	});

}

if($("#passwordCon").val()!=$("#password").val())
{

return 	Swal.fire({
	  position: 'bottom-end',
	  icon: 'error',
	  title: 'Your password and confirm password not math',
	  showConfirmButton: false,
	  timer: 2000
	});

}






		  $.ajax({
    		  method: "POST",
    	      url: "backend/server.php",
    		  data: {
    			  action   : "signup",
        		  Email:$("#email").val().trim(),
        		  Fname:$("#Fname").val(),
        		  Lname:$("#Lname").val(),
        		  Type:$("input[type='radio'][name='fav_language']:checked").val(),
        		  Password:$("#password").val(),
        		  CollegeID:$("#CollegesListSelect").val()


    		  	}

    		}).done(function( data ) {
    			 var jsonObj = JSON.parse(data);
					if(jsonObj.status=="success")
					{
						$("#switch").click();
						ClearData();
						Swal.fire({
							  position: 'bottom-end',
							  icon: 'success',
							  title: 'Your Account has been created',
							  showConfirmButton: false,
							  timer: 2000
							})


					}else{
						Swal.fire({
							  position: 'bottom-end',
							  icon: 'error',
							  title: jsonObj.msg,
							  showConfirmButton: false,
							  timer: 2000
							})
						}
    			 });



	});
	$("#Login").click(()=>{
		if($("#loginemail").val()=="")
		{

		return 	Swal.fire({
			  position: 'bottom-end',
			  icon: 'error',
			  title: 'Your Email Adderss required field',
			  showConfirmButton: false,
			  timer: 2000
			});

		}
		if(!validateEmail($("#loginemail").val()))
		{

		return 	Swal.fire({
			  position: 'bottom-end',
			  icon: 'error',
			  title: 'Your Email Adderss Not valid',
			  showConfirmButton: false,
			  timer: 2000
			});

		}

		if($("#loginPassword").val()=="")
		{

		return 	Swal.fire({
			  position: 'bottom-end',
			  icon: 'error',
			  title: 'Your Password required',
			  showConfirmButton: false,
			  timer: 2000
			});

		}


		 $.ajax({
	   		  method: "POST",
	   	      url: "backend/server.php",
	   		  data: {
	   			  action   : "login",
		   			Email:$("#loginemail").val().trim(),
	       		  Password:$("#loginPassword").val()


	   		  	}

	   		}).done(function( data ) {
	   			 var jsonObj = JSON.parse(data);
						if(jsonObj.Status=="success")
						{
							location.replace('index.php')


						}else{
							Swal.fire({
								  position: 'bottom-end',
								  icon: 'error',
								  title: jsonObj.msg,
								  showConfirmButton: false,
								  timer: 2000
								})
							}
	   			 });

		 });
	function validateEmail(email) {
	    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	    return re.test(String(email).toLowerCase());
	}
	function ClearData(){
		$("#email").val("");
		 $("#Fname").val("");
		 $("#Lname").val("");
		  $("#password").val("");
		  $("#email").val("");
		  $("#passwordCon").val("");

		}

</script>
</body>
</html>
