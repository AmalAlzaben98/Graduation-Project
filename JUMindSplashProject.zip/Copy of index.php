<?php
include 'setLang.php';
include 'lang.php';
?>
<!DOCTYPE html>
<html lang="<?php echo $lang;?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JU Mind Splash</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="css/rate.css">

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
</head>

<body>
    <!--navbar-->
    <nav>
        <!--logo and search-->
        <div class="left-side">
            <div class="logo">
                <img src="img/logo-mind.png" alt="">
            </div>

            <div class="search">
                <input type="text" placeholder="Search in JU mind splash" name="" id="">
            </div>
        </div>

        <!--tab icons-->
        <div class="tabs">
            <div class="tab-icon active">
                <div class="icon">
                    <img src="img/icons/home.svg" alt="">
                </div>
            </div>

            <div class="tab-icon">
                <div class="icon has-notification">
                    <img src="img/icons/flag.svg" alt="">
                </div>
            </div>

            <div class="tab-icon">
                <div class="icon">
                    <img src="img/icons/tv.svg" alt="">
                </div>
            </div>




            <div class="tab-icon">
                <div class="icon has-notification">
                    <img src="img/icons/calendar.svg" alt="">
                </div>
            </div>
        </div>

        <!--right side-->
        <div class="right-side">
            <div class="user">
                <div class="profile">
                    <img src="img/avatar/hero.png" alt="">
                </div>
                <h4>Anne</h4>
            </div>

            <!--icons-->
            <div class="user-icons">
                <div class="icon">
                    <img src="img/icons/plus.svg" alt="">
                </div>



                <div class="icon">
                    <img src="img/icons/bell.svg" alt="">
                </div>

                <div class="icon">
                    <img src="img/icons/arrow.svg" alt="">
                </div>
            </div>
        </div>
    </nav>


    <!--content-->
    <div class="wrapper">
        <div class="shortcuts">
            <div class="first-col">
                <div class="menu-item">
                    <div class="user">
                        <div class="profile">
                            <img src="img/avatar/hero.png" alt="">
                        </div>
                        <h4>Anne</h4>
                    </div>
                </div>



                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/icons/colored-people.svg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['User'];?> </h4>
                    </div>
                </div>



                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/icons/magnifier-690.svg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['ResearchRequest'];?> </h4>
                    </div>
                </div>

                <div class="menu-item" >
                    <div class="item-row">
                        <div class="icon more">
                            <img src="img/icons/arrow-down.svg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['seemore'];?>  </h4>
                    </div>
                </div>
            </div>

            <div class="second-col" id="category">

                <h6 class="title">
                    <?php echo $text[$lang]['Colleges'];?>
                </h6>



            </div>
        </div>



        <!--posts-->
        <div class="posts">
            <!-- stories -->


            <!--create post-->
            <div class="timeline">
                <div class="view create-post">
                    <div class="input">
                        <div class="user">
                            <div class="profile">
                                <img src="img/avatar/hero.png" alt="">
                            </div>
                        </div>
                        <input type="text" placeholder="What on your mind, Anne?" name="" id="">
                    </div>
                    <div class="media">
                        <div class="category">
                            <div class="option" data-toggle="modal" data-target="#addnewpost">
                                <div class="icon">
                                    <img src="img/icons/social-media-announcement-4548.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['Post'];?></span>
                            </div>

                            <div class="option">
                                <div class="icon">
                                    <img src="img/icons/research-689.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['Research'];?></span>
                            </div>

                            <div class="option">
                                <div class="icon">
                                    <img src="img/icons/calendar.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['Event'];?></span>
                            </div>
                        </div>
                    </div>
                </div>


                <!--post container-->
                <div class="view view-post-container smaller-margin">
                    <div class="view-post">
                        <div class="upper">
                            <div class="d-flex">
                                <div class="user">
                                    <div class="profile">
                                        <img src="img/avatar/5.jpg" alt="">
                                    </div>
                                </div>

                                <div class="info">
                                    <h6 class="name">
                                        diana barry
                                    </h6>
                                    <span class="time">1 hour ago</span>
                                </div>
                            </div>

                            <div class="dots">
                                <div class="dot"></div>
                            </div>
                        </div>

                        <div class="desc">
                            <p>Travellimg to the future 🌟 , it's alraedy 2020 🙋‍♂🌈🌴</p>
                        </div>

                        <div class="post-img">
                            <img src="img/posts/1.jpg" alt="">
                        </div>

                        <div class="actions-container">
                            <div class="action">
                                <div class="icon">
                                    <img src="img/icons/thumbs-up.svg" alt="">
                                </div>
                                <span>
                                    like
                                </span>
                            </div>

                            <div class="action">
                                <div class="icon">
                                    <img src="img/icons/comment.svg" alt="">
                                </div>
                                <span>
                                    comment
                                </span>
                            </div>

                            <div class="action">
                                <div class="icon">
                                    <img src="img/icons/share.svg" alt="">
                                </div>
                                <span>
                                    share
                                </span>
                            </div>
                        </div>

                        <div class="write-comment">
                            <div class="user">
                                <div class="profile">
                                    <img src="img/avatar/hero.png" alt="">
                                </div>
                            </div>
                            <div class="input">
                                <input type="text" placeholder="Write a comment" name="" id="">

                            </div>
                        </div>


                    </div>
                </div>

            </div>
        </div>

        <!--shortcuts 2 -events and chat- -->
        <div class="shortcuts shortcuts-2">
            <div class="second-col first-col">
                <div class="menu-item">
                    <div class="upper">
                        <h6><?php echo $text[$lang]['Yourpages'];?> </h6>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/st-2.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Post'];?></h4>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/st-1.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Research'];?></h4>
                    </div>
                </div>
                 <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/page-3.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Event'];?></h4>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon more">
                            <img src="img/icons/arrow-down.svg" alt="">
                        </div>
                        <h4> <?php echo $text[$lang]['seemore'];?></h4>
                    </div>
                </div>
            </div>

        </div>
    </div>

<div class="modal fade" style="background-color: #000000bd;" id="ModalPostorNews" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialogmargin" role="document">
    <div class="modal-content"  style="background-color: unset;"
    >

      <div class="modal-body modal-bodycustome">
      	<div class="container">
                <div class="row">
                    <div class="col-md-6 t-c">
                    <a href="" id="gotopost">
                                     <img style="width: 70%;    margin-bottom: 20px;"src="img/icons/social-media-announcement-45482.svg" alt="">
                                     <br>
                                     <span class="m-t"> <?php echo $text[$lang]['Post'];?></span>
</a>
 					</div>
 					<div class="col-md-6 t-c">
 					 <a href="" id="gotoresearch">
								<img style="width: 70%;margin-bottom: 20px;" src="img/icons/research-6892.svg" alt="">
								<br>
								<span class="m-t"> <?php echo $text[$lang]['Research'];?></span>
 					</a>
 					</div>
 					</div>
            </div>

      </div>

    </div>
  </div>
</div>

<div class="modal fade" style="background-color: #000000bd;" id="addnewpost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog " role="document">
    <div class="modal-content"  style="background-color: unset;"
    >

      <div class="modal-body " >
   <!--create post-->
   <div class="posts" style=" width: 100%; height: 198px; ">
            <div class="timeline">
                <div class="view create-post">
                    <div class="input">
<textarea id="postDescription" name="w3review" rows="4"  class="textAreaUi"cols="50">
</textarea>
                    </div>
                    <div class="post-img">
                            <img class="post-img-add" id="imagebase64Post" src="" alt="">
                        </div>
                    <div class="media">
                        <div class="category">
                            <div class="option pointer-c" id="openFile">
                                <div class="icon">
                                    <img src="img/icons/add.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['addImage'];?></span>

                            </div>
							<div class="publisbutn">
                                <?php echo $text[$lang]['publish'];?>
                            </div>
                            <input type="file"
       id="postImageInput" name="avatar"
       accept="image/png, image/jpeg" style="display: none;">

                        </div>
                    </div>
                </div>
                </div>
</div>
      </div>

    </div>
  </div>
</div>
      <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>  <script src="https://kendo.cdn.telerik.com/2019.3.1023/js/kendo.all.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/index.js"></script>
</body>

</html>