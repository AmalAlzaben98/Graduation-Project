<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "sql.php";
if(isset($_POST['action']) == false)
    die( "Action is not defined" );

$action = $_POST['action'];
$appLap = new Ebook ();
$appLap->$action();


class Ebook {
    private $data;
    private $file;
    private $query;
    private $encryptKey = "24525ashmoe462d";
    private $cipher     = "aes128";
    private $secret_iv  = "2223455223dsadhda";
    private $iv;


    public function __construct() {
        $this->query = new Sql();
        $this->data = $_POST;
        $this->file = $_FILES;
        $this->iv = substr(hash('sha256', $this->secret_iv), 0, 16);

        if(isset($this->data['user_id'])) {
            $this->data['user_id'] = $this->dencrypt($this->data['user_id']);
        }

    }

    public function login() {
        $this->emptyValidation($this->data);

        $password   = md5($this->data['Password']);
        $data = $this->query->get("User","Email = '{$this->data['Email']}' and Password = '{$password}'");

        if(count($data) > 0) {
            $data[0]['id'] = $this->encrypt($data[0]['UserID']);
            $_SESSION['UserID']=$data[0]['UserID'];
            $_SESSION['CategoryID']=$data[0]['Splactilst'];
            $_SESSION['Name']=$data[0]['Fname']." ".$data[0]['Lname'];
            $_SESSION['Fname']=$data[0]['Fname'];
            $_SESSION['Lname']=$data[0]['Lname'];
            $_SESSION['Image']=$data[0]['Image'];

            $this->sendBack(["Status" => 'success', "user_id" => $data[0]['UserID']]);
        }else
            $this->sendBack(["Status" => 'ERROR', "msg" =>'Check your username and password Please.']);

    }


    /*
     * Data => email
     * Data => name
     * Data => phone
     * Data => password
     *
     * */
    public function signup() {

        $this->emptyValidation($this->data);
        $msg = '';
        if (!filter_var($this->data['Email'], FILTER_VALIDATE_EMAIL)) {
            $msg = "Invalid email format.";
        }
        else{
            $data = $this->query->get("User", "Email = '{$this->data['Email']}'");
            if(count($data) > 0)
                $msg = 'This user already exists.';

        }

        if($msg != ''){
            $msgBack ['status'] = "ERROR";
            $msgBack ['msg'] = $msg;
            return $this->sendBack($msgBack);
        }
        //Generate a random string.
        $token = openssl_random_pseudo_bytes(16);

        //Convert the binary data into hexadecimal representation.
        $token = bin2hex($token);

        //Print it out for example purposes.
        $token;
        $insert = [];
        $insert ["Email"]       = $this->data['Email'];
        $insert ["Fname"]        = $this->data['Fname'];
        $insert ["Lname"]       = $this->data['Lname'];
        $insert ["Type"]       = $this->data['Type'];
        $insert ["Splactilst"]       = $this->data['CollegeID'];

        $insert ["Token"]       = $token;

        $insert ["Password"]    = md5($this->data['Password']);

        $res = $this->query->insert('User', $insert);
        $msg = [];
        if($res == 1)
            $msg ['status'] = "success";
            else {
                $msg ['status'] = "ERROR";
                $msg ['msg'] = $res;
            }
                $this->sendBack($msg);

    }

    private function uploadImage ($path, $file) {
        $target_dir = $path;
        $msgs=array();
        $msg="";
            $imageFileType = strtolower(pathinfo(basename($file["image"]["name"]),PATHINFO_EXTENSION));
            $target_file = $target_dir . rand(1,20000) . date("YmdHis") .".".$imageFileType;
            $uploadOk = 1;

//             // Check if image file is a actual image or fake image
//             $check = getimagesize($file["image"]["tmp_name"]);
//             if($check !== false) {
//                 $uploadOk = 1;
//             } else {
//                 $msg =  "File is not an image.";
//                 $uploadOk = 0;
//             }


            // Check if file already exists
            if (file_exists($target_file)) {
                $msg+= "Sorry, file already exists.";
                $uploadOk = 0;
            }


            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
                && $imageFileType != "gif"  ) {
                    $msg += "Sorry, only JPG, JPEG, PNG & epub & GIF files are allowed.";
                    $uploadOk = 0;
                }

                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    $msg += "Sorry, your file was not uploaded.";
                    // if everything is ok, try to upload file
                } else {
                    if (move_uploaded_file($file["image"]["tmp_name"], $target_file)) {

                    } else {
                        $msg += "Sorry, there was an error uploading your file.";
                    }
                }

                if($msg != ''){
                    $msgs ['status'] = "ERROR";
                    $msgs ['msg'] = $msg;
                    return $msg;
                }

                return [
                    "status" => "success",
                    "path" => $target_file
                ];
    }

    private function uploadFile ($path, $file) {
        $target_dir = $path;
        $msgs=array();
        $msg="";
            $imageFileType = strtolower(pathinfo(basename($file["book"]["name"]),PATHINFO_EXTENSION));
            $target_file = $target_dir . rand(1,20000) . date("YmdHis") .".".$imageFileType;
            $uploadOk = 1;

            // Check if file already exists
            if (file_exists($target_file)) {
                $msg += "Sorry, file already exists.";
                $uploadOk = 0;
            }


            // Allow certain file formats
            if($imageFileType != "pdf" ) {
                    $msg = "Sorry, only pdf file are allowed.";
                    $uploadOk = 0;
                }

                // Check if $uploadOk is set to 0 by an error
                if ($uploadOk == 0) {
                    $msg = "Sorry, your file was not uploaded.";
                    // if everything is ok, try to upload file
                } else {
                    if (move_uploaded_file($file["book"]["tmp_name"], $target_file)) {

                    } else {
                        $msg += "Sorry, there was an error uploading your file.";
                    }
                }

                if($msg != ''){

                    $msgs['status'] = "ERROR";
                    $msgs ['msg'] = $msg;
                    return $msgs;
                }


                return [
                    "status" => "success",
                    "path" => $target_file
                ];
    }

    public function addNewCategory() {

        $this->emptyValidation($this->data);

        $msg = '';

        $insert = [];
        $insert ["CategoryNameEn"]       = $this->data['CategoryNameEn'];
        $insert ["CategoryNameAr"]   = $this->data['CategoryNameAr'];
        $insert ["CategoryImage"]          = $this->data['CategoryImage'];
        $res = $this->query->insert('Category', $insert);

        $bookID = $this->query->lastId();

        $msg = [];
        if($res == 1)
            $msg = ["status" => "success", "Category" =>$bookID];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];


        $this->sendBack($msg);

    }
    public function addNewPost(){


        $msg = '';

        $insert = [];
        $insert ["UserID"]       = $_SESSION['UserID'];
        $insert ["PostDescription"]   = $this->data['PostDescription'];
        $insert ["PostImage"]          = $this->data['PostImage'];
        $insert ["CategoryID"]          = $this->data['CategoryID'];

        $res = $this->query->insert('Post', $insert);
        $bookID = $this->query->lastId();
        $msg = [];
        if($res == 1)
            $msg = ["status" => "success", "Category" =>$bookID];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];


                $this->sendBack($msg);

    }
    public function addNewEvent(){


        $msg = '';

        $insert = [];
        $insert ["UserID"]       = $_SESSION['UserID'];
        $insert ["EventTime"]   = $this->data['EventTime'];
        $insert ["EventImage"]          = $this->data['EventImage'];
        $insert ["EventName"]          = $this->data['EventName'];
        $insert ["EventDescription"]          = $this->data['EventDescription'];

        $res = $this->query->insert('Event', $insert);
        $bookID = $this->query->lastId();
        $msg = [];
        if($res == 1)
            $msg = ["status" => "success", "EventID" =>$bookID];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];


                $this->sendBack($msg);

    }
    public function getِAllEvent () {
        $data = $this->query->getJoin("Event join User on Event.UserID = User.UserID","","Event.*,User.Image,User.Fname,User.Lname");

        for($i=0;$i<count($data);$i++){
            $data[$i]["EventRoll"]=$this->query->get("EventRoll", "EventID = '{$data[$i]['EventID']}' and UserID='{$_SESSION['UserID']}'
            ");
        }
        $this->sendBack($data);

    }

    public function ChangeEventJoin() {
        $msg=array();
        $data = $this->query->get("EventRoll","EventID = {$this->data['EventID']} and UserID='{$_SESSION['UserID']}'");
        if(count($data) > 0) {
            $this->query->delete("EventRoll","EventRollID = '{$data[0]['EventRollID']}'");
            $msg = ["status" => "success", "msg" =>'Join'];
            $this->sendBack($msg);

        }else{
            $insert=[];
            $insert ["EventID"]   = $this->data['EventID'];
            $insert ["UserID"]   = $_SESSION['UserID'];
            $this->query->insert("EventRoll", $insert);
            $msg = ["status" => "success", "msg" =>'Left'];
            $this->sendBack($msg);

        }

    }
    public function getِAllCategory () {
        $data = $this->query->get("Category");
        $this->sendBack($data);

    }
    public function deleteSelectCategory() {
        $this->query->delete('Category', "CategoryID = {$this->data['CategoryID']}");
        $msg = ['status' => 'success'];
        $this->sendBack($msg);

    } public function deletePostLike() {
        $this->query->delete('PostLike', "PostID = {$this->data['PostID']} and UserID = {$_SESSION['UserID']}");
        $msg = ['status' => 'success'];
        $this->sendBack($msg);
    }
    public function addPostLike() {
        $insert = [];

        $insert ["PostID"]   = $this->data['PostID'];
        $insert ["UserID"]          = $_SESSION['UserID'];
        $res = $this->query->insert('PostLike', $insert);
        if($res == 1)
        $msg = ['status' => 'success'];
        $this->sendBack($msg);
    }
    public function addPostComment() {
        $insert = [];

        $insert ["PostID"]   = $this->data['PostID'];
        $insert ["Comment"]   = $this->data['Comment'];
        $insert ["UserID"]          = $_SESSION['UserID'];
        $res = $this->query->insert('PostComment', $insert);
        if($res == 1)
            $msg = ['status' => 'success'];
            $addPostCommentID = $this->query->lastId();
            $data = $this->query->getJoin("PostComment join User on PostComment.UserID = User.UserID"
                ,"PostComment.PostCommentID = {$addPostCommentID}");

            $this->sendBack($data);

    }
    public function addResearchComment() {
        $insert = [];

        $insert ["ResearchID"]   = $this->data['PostID'];
        $insert ["Comment"]   = $this->data['Comment'];
        $insert ["UserID"]          = $_SESSION['UserID'];
        $res = $this->query->insert('ResearchComment', $insert);
        if($res == 1)
            $msg = ['status' => 'success'];
            $addPostCommentID = $this->query->lastId();
            $data = $this->query->getJoin("ResearchComment join User on ResearchComment.UserID = User.UserID"
                ,"ResearchComment.ResearchCommentID = {$addPostCommentID}");

            $this->sendBack($data);

    }

    public function getAllUsers () {
        $data = $this->query->get("User "
            ,"","User.UserID ,User.Email ,User.Fname,User.Lname,User.Splactilst,User.Image");

        for($i=0;$i<count($data);$i++){
            $data[$i]["Post"]=$this->query->get("Post", "UserID = '{$data[$i]['UserID']}'
            ","count(PostID) as PostCount");

            $data[$i]["Research"]=$this->query->get("Research", "UserID = '{$data[$i]['UserID']}'
            ","count(ResearchID) as ResearchCount");

            $data[$i]["Event"]=$this->query->get("Event", "UserID = '{$data[$i]['UserID']}'
            ","count(EventID) as EventCount");


        }
        $this->sendBack($data);

    }
    public function addResearch() {

        if(isset($this->file["book"]) == 0)
            return ["status" => "ERROR", "msg" => "Upload file first"];


                $file_res = $this->uploadFile("../web/", $this->file);


                    $msg = '';

                    $insert = [];
                    $insert ["FilePath"]            = str_replace("../", "", $file_res['path']);
                    $insert ["UserID"]           = $_SESSION['UserID'];
                    $insert ["Describeion"]   = $this->data['ResearchDescription'];
                    $insert ["CategoryID"]          = $this->data['CategoryID'];
                    $res = $this->query->insert('Research', $insert);

                    $bookID = $this->query->lastId();

                    $msg = [];
                    if($res == 1)
                        $msg = ["status" => "success", "Research" =>$bookID];
                        else
                            $msg = ["status" => "ERROR", "msg" =>$res];


                            $this->sendBack($msg);

    }
    public function addBookInfo () {

        $this->emptyValidation($this->data);
        $data = $this->query->get("book", "id = '{$this->data['book_id']}'");
        if(count($data) == 0)
            $this->sendBack( ["status" => "ERROR", "msg" => "No book found in this id"] );

            if($this->data['lang_id'] != 1 && $this->data['lang_id'] != 2)
                $this->sendBack( ["status" => "ERROR", "msg" => "Lang id must be 1 or 2"] );

                $insert = [];
                $insert ["book_id"]       = $this->data['book_id'];
                $insert ["lang_id"]       = $this->data['lang_id'];
                $insert ["description"]   = $this->data['description'];
                $insert ["name"]          = $this->data['name'];

                $res = $this->query->insert('book_info', $insert);
                if($res == 1)
                    $msg = ["status" => "success"];
                    else
                        $msg = ["status" => "ERROR", "msg" =>$res];
                        $this->sendBack($msg);

    }

    public function UpdateCategory () {

        $update=[];
                if($this->data['CategoryNameEn']!=null)
                {
                    $update ["CategoryNameEn"]          = $this->data['CategoryNameEn'];
                }
                if($this->data['CategoryNameAr']!=null)
                {
                    $update ["CategoryNameAr"]          = $this->data['CategoryNameAr'];
                }
                if($this->data['CategoryImage']!=null)
                {
                    $update ["CategoryImage"]          = $this->data['CategoryImage'];
                }


                $res = $this->query->update('Category', $update, "CategoryID = '{$this->data['CategoryID']}'");
                if($res == 1)
                    $msg = ["status" => "success"];
                    else
                        $msg = ["status" => "ERROR", "msg" =>$res];
                        $this->sendBack($msg);

    }

    public function deleteBook() {
        $this->query->delete('book', "id = {$this->data['book_id']}");
        $msg = ['status' => 'success'];
        $this->sendBack($msg);

    }

    public function addSocialLinks () {

        $this->emptyValidation($this->data);
        $this->data['icon']= strtolower($this->data['icon']);
        $data = $this->query->get("social_links", "LOWER(icon) = '{$this->data['icon']}'");
        if(count($data) == 0) {

            $insert = [];
            $insert ["icon"]       = $this->data['icon'];
            $insert ["link"]       = $this->data['link'];

            $res = $this->query->insert('social_links', $insert);
        }else {
            $this->data['id'] = $data[0]['id'];
            $this->updateSocialLinks();
        }

        if($res == 1)
            $msg = ["status" => "success"];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];
                $this->sendBack($msg);

    }

    public function Setnewpassword() {

        $update = [];
        $update ["password"]       =  md5($this->data['password']);
        $res = $this->query->update('users', $update, "id = '{$this->data['user_ids']}'");
        $msg = ["status" => "success"];
        $this->sendBack($msg);


    }
    public function UpdateUserImage() {

        $update = [];
        $update ["Image"]       = $this->data['Image'];
        $res = $this->query->update('User', $update, "UserID = '{$_SESSION['UserID']}'");
        $_SESSION['Image']=$this->data['Image'];

        $msg = ["status" => "success"];
        $this->sendBack($msg);


    }
    public function updateCopouns() {

        $update = [];
        $update ["promoCode_Status"]       = $this->data['promoCode_Status'];
        $res = $this->query->update('promoCode', $update, "promoCode_id = '{$this->data['promoCode_id']}'");

        $msg = ["status" => "success"];
        $this->sendBack($msg);


    }
    public function updateUserPassword() {

        $update = [];
        $update ["password"]        = md5($this->data['password']);
        $res = $this->query->update('users', $update, "id = '{$this->data['id']}'");
        $msg = ["status" => "success"];
        $this->sendBack($msg);


    }

    public function deleteSocialLinks () {
        $this->query->delete('social_links', "id = {$this->data['id']}");
        $msg = ['status' => 'success'];
        $this->sendBack($msg);

    }


    public function addAboutSection () {

        $this->emptyValidation($this->data);

        if($this->data['lang_id'] != 1 && $this->data['lang_id'] != 2)
            $this->sendBack( ["status" => "ERROR", "msg" => "Lang id must be 1 or 2"] );

        $insert = [];
        $insert ["text"]       = $this->data['text'];
        $insert ["name"]       = $this->data['name'];
        $insert ["lang_id"]    = $this->data['lang_id'];

        $res = $this->query->insert('about_sections', $insert);

        if($res == 1)
            $msg = ["status" => "success"];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];
                $this->sendBack($msg);

    }

    public function updateAboutSection() {

        $update = [];
        $update ["text"]       = $this->data['text'];
        $update ["name"]       = $this->data['name'];

        $res = $this->query->update('about_sections', $update, "id = '{$this->data['id']}'");

        if($res == 1)
            $msg = ["status" => "success"];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];
        $this->sendBack($msg);



    }

    public function deleteAboutSection () {
        $this->query->delete('about_sections', "id = {$this->data['id']}");
        $msg = ['status' => 'success'];
        $this->sendBack($msg);

    }

    public function addSliderImages () {

        if(isset($this->file["image"]) == 0)
            return ["status" => "ERROR", "msg" => "Upload image first"];

        if($this->data['lang_id'] != 1 && $this->data['lang_id'] != 2)
            $this->sendBack( ["status" => "ERROR", "msg" => "Lang id must be 1 or 2"] );

        $img_res = $this->uploadImage("../slider/", $this->file);

        $insert = [];
        $insert['slider_image']     = str_replace("../", "", $img_res['path']);
        $insert['title']            = $this->data['title'];
        $insert['text']             = $this->data['text'];
        $insert['lang_id']           = $this->data['lang_id'];
        $res = $this->query->insert('slider', $insert);

        if($res == 1)
            $msg = ["status" => "success"];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];

        $this->sendBack($msg);


    }
    public function addNewCoupons () {



                $insert = [];
                $insert['promoCode_name']     = $this->data['promoCode_name'];
                $insert['promoCode_book_id']            = $this->data['promoCode_book_id'];
                $insert['Quantity_of_use']            = $this->data['Quantity_of_use'];

                $insert['Valed_To']            = $this->data['Valed_To'];

                $insert['promoCode_discountPircantge']             = $this->data['promoCode_discountPircantge'];
                $insert['promoCode_Status']           = 1;
                $res = $this->query->insert('promoCode', $insert);

                if($res == 1)
                    $msg = ["status" => "success"];
                    else
                        $msg = ["status" => "ERROR", "msg" =>$res];

                        $this->sendBack($msg);


    }
    public function updateSliderImages () {

        if(isset($this->file["image"]) == 0)
            return ["status" => "ERROR", "msg" => "Upload image first"];

            if($this->data['lang_id'] != 1 && $this->data['lang_id'] != 2)
                $this->sendBack( ["status" => "ERROR", "msg" => "Lang id must be 1 or 2"] );

                $img_res = $this->uploadImage("../slider/", $this->file);

                $insert = [];
                $insert['slider_image']     = str_replace("../", "", $img_res['path']);
                $insert['title']            = $this->data['title'];
                $insert['text']             = $this->data['text'];

                $res = $this->query->update('slider', $update, "id = '{$this->data['slider_id']}'");

        if($res == 1)
            $msg = ["status" => "success"];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];

        $this->sendBack($msg);


    }

    public function getSliderImages () {
        $data = $this->query->get("slider");
        $this->sendBack($data);

    }

    public function getCommentPost () {
        $data = $this->query->getJoin("PostComment join User on PostComment.UserID = User.UserID"
            ,"PostComment.PostID = {$this->data['PostID']}");

        $this->sendBack($data);

    }
    public function getCommentResearch () {
        $data = $this->query->getJoin("ResearchComment join User on ResearchComment.UserID = User.UserID"
            ,"ResearchComment.ResearchID = {$this->data['PostID']}");

        $this->sendBack($data);

    }
    public function deleteSliderImage () {
        $this->query->delete('slider', "id = {$this->data['slider_id']}");
        $msg = ['status' => 'success'];
        $this->sendBack($msg);

    }


    public function saveReview() {

        $this->emptyValidation($this->data);



//         $data = $this->query->get("review", "user_id = '{$this->data['user_id']}' and book_id = '{$this->data['book_id']}'");
//         if(count($data) == 0){

            $insert = [];
            $insert ["user_id"]     = $this->data['user_id'];
            $insert ["book_id"]     = $this->data['book_id'];
            $insert ["rate"]        = $this->data['rate'];
            $insert ["note"]        = $this->data['note'];

            $res = $this->query->insert('review', $insert);
//         }else
//             $res = $this->updateReview();

        $msg = [];
        if($res == 1)
            $msg ['status'] = "success";
            else
                $msg ['status'] = "ERROR :". $res;

                $this->sendBack($msg);

    }

    public function updateReview () {


        $this->emptyValidation($this->data);

        if($this->data['rate'] < 0 || $this->data['rate'] > 5) {
            $msg ['status'] = "ERROR : the rate must be between 0 and 5";
            return $this->sendBack($msg);
        }

        $update = [];
        $update ["user_id"]     = $this->data['user_id'];
        $update ["book_id"]     = $this->data['book_id'];
        $update ["rate"]        = $this->data['rate'];
        $update ["note"]        = $this->data['note'];

        $res = $this->query->update('review', $update, "user_id = '{$this->data['user_id']}' and user_id = '{$this->data['book_id']}'");

        $msg = [];
        if($res == 1)
            $msg ['status'] = "success";
            else
                $msg ['status'] = "ERROR :". $res;

        $this->sendBack($msg);


    }

    public function getReviewByBook() {

        $data = $this->query->getJoin(
            "review join book on review.book_id = book.id
            join users on users.id = review.user_id where book.id = {$this->data['book_id']}", "", "review.*, book.*, users.name");

        $reviews = $this->query->get( "review",
            "review.book_id = '{$this->data['book_id']}' group by rate", "rate, count(rate) as count");

        $reviewTotal =  $this->query->get( "review",
            "review.book_id = '{$this->data['book_id']}'", "sum(rate) / count(rate) as total_rate, count(rate) as count");
        $msg = [
            "status" => "success",
            'body' => $data,
            "TotalReviewCount" =>$reviewTotal[0]['count'],
            "AllReviewCount" =>$reviewTotal[0]['total_rate'],
            "5StarCount" =>0,
            "4StarCount" =>0,
            "3StarCount" =>0,
            "2StarCount" =>0,
            "1StarCount" =>0

        ];

        foreach($reviews as $key => $review) {
            if (isset( $msg [$review['rate']."StarCount"]))
                $msg [$review['rate']."StarCount"] = $review['count'];
        }
        if($msg['AllReviewCount']==null)
        {
            $msg['AllReviewCount']="0";
        }
        $this->sendBack($msg);
    }

    public function getCategoryPost () {

        $data = $this->query->getJoin(
            "Post join Category on Post.CategoryID = Category.CategoryID
            join User on Post.UserID = User.UserID","Post.CategoryID={$this->data['CategoryID']}","Post.PostID
,Post.PostImage,Post.PostDescription,Post.CreateAt,User.Fname,User.Lname,User.Image");
        for($i=0;$i<count($data);$i++){
            $data[$i]["haveLike"]=$this->query->get("PostLike", "PostID = '{$data[$i]['PostID']}'
 and  UserID='{$_SESSION['UserID']}'");


        }

        $this->sendBack($data);
    }
    public function getCategoryResearch () {

        $data = $this->query->getJoin(
            "Research join Category on Research.CategoryID = Category.CategoryID
            join User on Research.UserID = User.UserID","Research.CategoryID={$this->data['CategoryID']}","Research.*,User.Fname,User.Lname,User.Image");
        for($i=0;$i<count($data);$i++){
            $data[$i]["rate"]=$this->query->get("ResearchRate", "ResearchID = '{$data[$i]['ResearchID']}'
           ","count(ResearchID) as ResearchCount  , sum(Rate) as ResearchSum");
        }
        $this->sendBack($data);
    }

    public function RateNow(){
        $data = [];
        $this->emptyValidation($this->data);

        $reviews = $this->query->get( "ResearchRate",
            "UserID = '{$_SESSION['UserID']}' and ResearchID='{$this->data['ResearchID']}'");

        if(count($reviews) > 0){
            $update = [];
            $update['Rate']              = $this->data['Rate'];
            $res = $this->query->update('ResearchRate', $update,"ResearchRateID={$reviews[0]['ResearchRateID']}");
        }else{
            $insert = [];
            $insert['UserID']            = $_SESSION['UserID'];
            $insert['ResearchID']            = $this->data['ResearchID'];
            $insert['Rate']              = $this->data['Rate'];
            $res = $this->query->insert('ResearchRate', $insert);
        }

        $data["rate"]=$this->query->get("ResearchRate", "ResearchID = '{$this->data['ResearchID']}'
        ","count(ResearchID) as ResearchCount  , sum(Rate) as ResearchSum");
        $this->sendBack($data);


    }

    public function payment () {

        $this->emptyValidation($this->data);

        $insert = [];
        $insert['UserID']            = $_SESSION['UserID'];
        $insert['book_id']            = $this->data['book_id'];
        $insert['price']              = $this->data['price'];
        $res = $this->query->insert('payment', $insert);

        if($res == 1)
            $msg = ["status" => "success"];
            else
                $msg = ["status" => "ERROR", "msg" =>$res];

                $this->sendBack($msg);
    }

    public function getUserById() {
        $this->emptyValidation($this->data);
        $data = $this->query->get("users","id = '{$this->data['user_id']}'", "name, email, phone, user_type, created_at");


        $this->sendBack($data);
    }

    public function dicressQuantity_of_use(){

            $Quantity_of_use= $this->query->get('promoCode', "promoCode_name = '{$this->data['promoCode']}' and promoCode_book_id='{$this->data['book_id']}'","Quantity_of_use");

            $update ["Quantity_of_use"]= ($Quantity_of_use[0]['Quantity_of_use'])-1;
            $res = $this->query->update('promoCode', $update, "promoCode_name = '{$this->data['promoCode']}'");

    }
    public function makePayment(){
        $insert = [];
        $insert ["user_id"]         = $this->data['user_id'];
        $insert ["book_id"]         = $this->data['book_id'];
        $insert ["price"]           = $this->data['price'];
        $insert ["PromoCode"]       = $this->data['promoCode'];
        if($this->data['promoCode']!="0"){
                    $this->dicressQuantity_of_use();
                }

        $res = $this->query->insert('payment', $insert);


        $result['status'] = 'success';
        $result['msg']    = "Your purchase has been successfully";
        $this->sendBack($result);
    }


    public function getSocialLinkss() {

        $data = $this->query->get("social_links");
        $this->sendBack($data);
    }


    public function getAboutSections() {

        $DataResult=array();

        $DataResult["body"]  =$this->query->get("about_sections", "lang_id = '{$this->data['lang_id']}'");
        if($DataResult["body"]!=null)
        {
            $DataResult["status"]="succeed";
        }
        else{
            if($this->data['lang_id']=="1"){
                $DataResult["status"]="Failed No data available";}
                else {
                    $DataResult["status"]="فشل لا توجد بيانات متاحة";
                }

        }
        $this->sendBack($DataResult);

    }
    public function getUserCount() {
        $DataResult["body"]['userCount']= $this->query->get("users","user_type=0","count(id) as userCount");
        $DataResult["body"]['bookCount']= $this->query->get("book","","count(id) as bookCount");
        $DataResult["body"]['paymentCount']= $this->query->get("payment","","count(id) as paymentCount");
        if($DataResult["body"]!=null)
        {
            $DataResult["status"]="succeed";
        }
        $this->sendBack($DataResult);
    }
    public function getLangs() {
        $DataResult=array();
        $BookOrginalPice;
        $curemt=date("yyyy/mm/dd");
        $data= $this->query->get("promoCode","promoCode_name = '{$this->data['promoCode_name']}' and promoCode_book_id = '{$this->data['promoCode_book_id']}'  and  promoCode_Status = 1  and Quantity_of_use>0 and Valed_To>='$curemt' ");
        if($data!=null)
        {
            $BookOrginalPice=$this->query->get("book","id = '{$this->data['promoCode_book_id']}' ","price");
            $BookOrginalPice=($BookOrginalPice[0]["price"])-($BookOrginalPice[0]["price"]*($data[0]['promoCode_discountPircantge']/100));
            $DataResult["status"]="succeed";
            $DataResult["newPrice"]=$BookOrginalPice;

        }
        else {
            $DataResult["status"]="error";
            $DataResult["msg"]="Code not fond";
        }
        $this->sendBack($DataResult);
    }
    public function getPromoCode() {

        $data = $this->query->get("lang");
        $this->sendBack($data);
    }
    public function getAllBooksAdmin () {
        $DataResult=array();

        $DataResult["body"]  =  $this->query->get("book");
        if($DataResult["body"]!=null)
        {
            $DataResult["status"]="succeed";
        }
        else{
            $DataResult["status"]="Failed No data available";

        }
        $this->sendBack($DataResult);

    }
    public function getAllCopouns () {
        $DataResult=array();

        $DataResult["body"] = $this->query->getJoin("
            promoCode join book on promoCode.promoCode_book_id = book.id

           ","","promoCode.*,book.name");
        if($DataResult["body"]!=null)
        {
            $DataResult["status"]="succec";
        }else{
            $DataResult["status"]="No Data Available";
        }
        $this->sendBack($DataResult);
    }
    public function getAllBooks () {
        $DataResult=array();

        $DataResult["body"]  =  $this->query->subQurery("{$this->data['lang_id']}");
        if($DataResult["body"]!=null)
        {
            $DataResult["status"]="succeed";
        }
        else{
            if($this->data['lang_id']=="1"){
            $DataResult["status"]="Failed No data available";}
            else {
                $DataResult["status"]="فشل لا توجد بيانات متاحة";
            }

        }
        $this->sendBack($DataResult);

    }

    public function getBookById () {
        $DataResult=array();
        $_access_checker = $this->query->get("payment", "book_id = '{$this->data['book_id']}' and user_id = '{$this->data['user_id']}'");
        $DataResult["body"]  = $this->query->get("book ","  book.id= '{$this->data['book_id']}'");
        if(count($_access_checker) > 0) {

            $DataResult["access_checker"]="Yes";
        }else {
            $DataResult["access_checker"]="No";
        }
        if($DataResult["body"]!=null)
        {
            $DataResult["status"]="succeed";
        }
        else{

                $DataResult["status"]="Failed No data available";
            }
            $this->sendBack($DataResult);
    }


    public function getAllPayments () {
        $DataResult=array();

        $DataResult["body"] = $this->query->getJoin("
            payment join users on payment.user_id = users.id
            join book on payment.book_id = book.id
           ","","payment.id as paymentID , payment.created_at as Date , payment.price ,users.name as Client");
        if($DataResult["body"]!=null)
        {
            $DataResult["status"]="succeed";
        }else{
            $DataResult["status"]="No Data Available";
        }
        $this->sendBack($DataResult);
    }

    public function getPaymentsByUserId () {

        $data = $this->query->getJoin("
            payment join book on payment.book_id = book.id
            join book_info on book_info.book_id = book.id",
            "payment.user_id = '{$this->data['user_id']}'","","payment *");
        $this->sendBack($data);
    }

    public function getPaymentsByBookId () {

        $data = $this->query->getJoin("
            payment join book on payment.book_id = book.id
            join book_info on book_info.book_id = book.id",
            "payment.book_id = '{$this->data['book_id']}'");
        $this->sendBack($data);
    }
    public function CheckUserToken(){
        $result=array();
        $RestToken=$this->data['RestToken'];
        $Token=$this->data['Token'];
        $password="lkfdsajlfjskdajflka45fds4a";
        $RestToken=openssl_decrypt($RestToken,"AES-128-ECB",$password);
        $data = $this->query->get("users","id = $RestToken and password='{$Token}' ");
        if($data != null)
        {
            $result['status']="success";
            $result['id']=$data[0]['id'];
        }
       else{
        $result['status']="Error";
         }
         $this->sendBack($result);
    }
    public function forgetpassword(){
        $result=array();
        $data = $this->query->get("users",
            "(email = '{$this->data['email']}') ");
        if($data != null)
        {
            $RestToken=$data[0]['id'];
            $Token=$data[0]['password'];
            $string_to_encrypt="Test";
            $password="lkfdsajlfjskdajflka45fds4a";
            $RestToken=openssl_encrypt($RestToken,"AES-128-ECB",$password);
   //         $Token=openssl_decrypt($RestToken,"AES-128-ECB",$password);
            $url="https://book1.meet-skype.com/ForgetPassword.php?Token=$Token&RestToken=$RestToken";
            $sendEmail=$this->sendEmail($this->data['email'],$url);
            if($sendEmail)
            {
                $result['status']="success";
            }
        }else{
            $result['status']="Error";
        }
        $this->sendBack($result);
    }
    public function sendEmail($email,$url){
        $result;
        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'meet-skype.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'info@meet-skype.com';                     //SMTP username
            $mail->Password   = '996100288@aA@';                               //SMTP password
            $mail->Port       = 25;                                    //TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

            //Recipients
            $mail->setFrom('info@meet-skype.com', 'Forgot password');
            $mail->addAddress($email);     //Add a recipient

            //Attachments
            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'forgot password';
            $mail->Body    = 'We heard that you lost your Ghalia  password. Sorry about that!<br>

But don’t worry! You can use the following link to reset your password:<br>

<a href="'.$url.'">'.$url.'</a><br>


Thanks,<br>
The Ghalia Team';

            $mail->send();
            $result='true';
        } catch (Exception $e) {
            $result= "false";
        }
        return $result;
    }

    private function emptyValidation ($data){
        foreach ($data as $k => $v) {
            if($v == '')
                return $this->sendBack(['status' => "ERROR: this $k is required"]);
        }
    }


    private function sendBack($data) {
        echo json_encode($data);
        die();
    }

    private function encrypt ($text) {

        $text =  (openssl_encrypt($text, $this->cipher, $this->encryptKey, $options=0, $this->iv));
        return base64_encode($text);
    }

    private function dencrypt($text) {
        $text = base64_decode($text);
        $original_plaintext = openssl_decrypt($text, $this->cipher, $this->encryptKey, $options=0, $this->iv);
        return $original_plaintext;
    }


}


?>