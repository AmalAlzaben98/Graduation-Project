<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['UserID']) && $_SESSION['UserID']=="")
    header("Location:login.php");
    include 'setLang.php';
    include 'lang.php';
    date_default_timezone_set('Asia/Amman');
?>
<!DOCTYPE html>
<html lang="<?php echo $lang;?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JU Mind Splash</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
            <link rel="stylesheet" href="css/users.css">

</head>

<body style="<?= $lang=="En"?"direction:ltr;":"direction: rtl;"?>">
    <!--navbar-->

    <?php
    include 'UpperPage.php';
    ?>



    <!--content-->
    <div class="wrapper">

    <?php
    include 'LeftSideBar.php';
    ?>



        <!--posts-->
        <div class="posts">
            <!-- stories -->


            <!--create post-->
            <div class="timeline">








<div class="container">
	<div class="row" id="Users">






	</div>
</div>












            </div>
        </div>

        <!--shortcuts 2 -events and chat- -->
        <div class="shortcuts shortcuts-2">
            <div class="second-col first-col">
                <div class="menu-item">
                    <div class="upper">
                        <h6><?php echo $text[$lang]['Yourpages'];?> </h6>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/st-2.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Post'];?></h4>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/st-1.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Research'];?></h4>
                    </div>
                </div>
                 <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/page-3.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Event'];?></h4>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon more">
                            <img src="img/icons/arrow-down.svg" alt="">
                        </div>
                        <h4> <?php echo $text[$lang]['seemore'];?></h4>
                    </div>
                </div>
            </div>

        </div>
    </div>

<div class="modal fade" style="background-color: #000000bd;" id="ModalPostorNews" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialogmargin" role="document">
    <div class="modal-content"  style="background-color: unset;"
    >

      <div class="modal-body modal-bodycustome">
      	<div class="container">
                <div class="row">
                    <div class="col-md-6 t-c">
                    <a href="" id="gotopost">
                                     <img style="width: 70%;    margin-bottom: 20px;"src="img/icons/social-media-announcement-45482.svg" alt="">
                                     <br>
                                     <span class="m-t"> <?php echo $text[$lang]['Post'];?></span>
</a>
 					</div>
 					<div class="col-md-6 t-c">
 					 <a href="" id="gotoresearch">
								<img style="width: 70%;margin-bottom: 20px;" src="img/icons/research-6892.svg" alt="">
								<br>
								<span class="m-t"> <?php echo $text[$lang]['Research'];?></span>
 					</a>
 					</div>
 					</div>
            </div>

      </div>

    </div>
  </div>
</div>

<div class="modal fade" style="background-color: #000000bd;" id="addnewpost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog " role="document">
    <div class="modal-content"  style="background-color: unset;"
    >

      <div class="modal-body " >
   <!--create post-->
   <div class="posts" style=" width: 100%; height: 198px; ">
            <div class="timeline">
                <div class="view create-post">
                    <div class="input">
<textarea id="postDescription" name="w3review" rows="4"  class="textAreaUi"cols="50">
</textarea>
                    </div>
                    <div class="post-img">
                            <img class="post-img-add" id="imagebase64Post" src="" alt="">
                        </div>
                    <div class="media">
                        <div class="category">
                            <div class="option pointer-c" id="openFile">
                                <div class="icon">
                                    <img src="img/icons/add.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['addImage'];?></span>

                            </div>
							<div class="publisbutn">
                                <?php echo $text[$lang]['publish'];?>
                            </div>
                            <input type="file"
       id="postImageInput" name="avatar"
       accept="image/png, image/jpeg" style="display: none;">

                        </div>
                    </div>
                </div>
                </div>
</div>
      </div>

    </div>
  </div>
</div>
      <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
<?php
include 'SheardJs.php';?>

<script>

$.ajax({
	  method: "POST",
  url: "backend/server.php",
	  data: {
		  action   : "getAllUsers",

	  	}
	}).done(function( data ) {
		 var jsonObj = JSON.parse(data);
		 console.log(jsonObj);
		 for(var i=0;i<jsonObj.length;i++){
			var  obj =jsonObj[i];
			 var user="";
			 user='<div class="col-md-6">'
			     +'<div class="profile-card-4 text-center"><img src="'+obj.Image+'" class="img img-responsive">'
			     +'<div class="profile-content">'
			     +'<div class="profile-description">'+obj.Fname+" "+obj.Lname
			     +'<br><a href="mailto:'+obj.Email+'">'+obj.Email+'</a>'
			     +'</div>'
			     +'<div class="row" style="display: flex;">'
			     +'<div class="col-md-4">'
			     +'<div class="profile-overview">'
			     +'<p>Post</p>'
			     +'<h4>'+obj.Post[0].PostCount+'</h4></div>'
			     +'</div>'
			     +'<div class="col-md-4">'
			     +'<div class="profile-overview">'
			     +'<p>Research</p>'
			     +'<h4>'+obj.Research[0].ResearchCount+'</h4></div>'
			     +'</div>'
			     +'<div class="col-md-4">'
			     +'<div class="profile-overview">'
			     +'<p>Event</p>'
			     +'<h4>'+obj.Event[0].EventCount+'</h4></div>'
			     +'</div>'
			     +'</div>'
			     +'</div>'
			     +'</div>'
			     +'</div>';

			 $("#Users").append(user);

			 }

	});
</script>
</body>

</html>