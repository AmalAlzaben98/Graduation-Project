<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$lang="";
if (isset($_SESSION['lang']))
{
    $lang=$_SESSION['lang'];

}
else{
    $lang="En";

}
if(isset($_POST['action']) && $_POST['action']=="ChangeLang")
{
    if($_SESSION['lang']=="Ar"){
        $_SESSION['lang']="En";
    }else{
        $_SESSION['lang']="Ar";
    }
    $lang=$_SESSION['lang'];
    print_r("Done");
}
?>