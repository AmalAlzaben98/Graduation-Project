<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['UserID']) && $_SESSION['UserID']=="")
    header("Location:login.php");
include 'setLang.php';
include 'lang.php';
date_default_timezone_set('Asia/Amman');

?>
<!DOCTYPE html>
<html lang="<?php echo $lang;?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JU Mind Splash</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/rate.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
</head>

<body style="<?= $lang=="En"?"direction:ltr;":"direction: rtl;"?>">
    <!--navbar-->

    <?php
    include 'UpperPage.php';
    ?>





    <!--content-->
    <div class="wrapper">


    <?php
    include 'LeftSideBar.php';
    ?>




        <!--posts-->
        <div class="posts">
            <!-- stories -->


            <!--create post-->
            <div class="timeline">
                <div class="view create-post">
                    <div class="input">
                        <div class="user">
                            <div class="profile">
                                <img src="<?= $_SESSION['Image'] ?>" alt="">
                            </div>
                        </div>
                        <input type="text" placeholder="What on your mind, <?=  $_SESSION['Fname'] ?>?" name="" id="">
                    </div>
                    <div class="media">
                        <div class="category">
                            <div class="option" data-toggle="modal" data-target="#addnewpost">
                                <div class="icon">
                                    <img src="img/icons/social-media-announcement-4548.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['Post'];?></span>
                            </div>

                            <div class="option">
                                <div class="icon">
                                    <img src="img/icons/research.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['Research'];?></span>
                            </div>

                            <div class="option">
                                <div class="icon">
                                    <img src="img/icons/calendar.svg" alt="">
                                </div>
                                <span> <?php echo $text[$lang]['Event'];?></span>
                            </div>
                        </div>
                    </div>
                </div>


                <!--post container-->
            	<div class="Postcontainer" id="Postcontainer">

            	</div>

            </div>
        </div>

        <!--shortcuts 2 -events and chat- -->
        <div class="shortcuts shortcuts-2">
            <div class="second-col first-col">
                <div class="menu-item">
                    <div class="upper">
                        <h6><?php echo $text[$lang]['Yourpages'];?> </h6>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/st-2.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Post'];?></h4>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/st-1.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Research'];?></h4>
                    </div>
                </div>
                 <div class="menu-item">
                    <div class="item-row">
                        <div class="icon">
                            <img src="img/stories/page-3.jpeg" alt="">
                        </div>
                        <h4><?php echo $text[$lang]['Event'];?></h4>
                    </div>
                </div>

                <div class="menu-item">
                    <div class="item-row">
                        <div class="icon more">
                            <img src="img/icons/arrow-down.svg" alt="">
                        </div>
                        <h4> <?php echo $text[$lang]['seemore'];?></h4>
                    </div>
                </div>
            </div>

        </div>
    </div>








<div class="modal fade" style="background-color: #000000bd;" id="ModalPostorComments" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialogmargin" role="document" style="height: 80vh; margin: 10vh auto;">
    <div class="modal-content"  style="background-color: unset;height: 100%;"
    >

      <div class="modal-body modal-bodycustome posts " style="width: 100%;padding: unset;background-color: #348763;max-height: 80vh;">
      	<div class="container timeline" style="height: 100%;">
                <div class="Postcontainer" style="height: 100%;">
                        <div class="view view-post-container smaller-margin" style="height: 100%;margin-top: unset;">
                           <div class="view-post" style="height: 100%;">
                              <div class="upper" id="listcomment" style="display: block; height: 79%; max-height: 79%; overflow-y: scroll;">








                              </div>
                              <div class="write-comment" style="    height: 21%;">
                                 <div class="user">
                                    <div class="profile"><img src="img/avatar/hero.png" alt=""></div>
                                 </div>
                                 <div class="input"><input type="text" class="Writeacomment" placeholder="Write a comment" name="" id="Writeacomment"></div>
                              </div>
                           </div>
                        </div>
                      </div>
            </div>

      </div>

    </div>
  </div>
</div>




      <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>

    <script src="js/owl.carousel.min.js"></script>
    <?php include 'js/indexjs.php';

    include 'SheardJs.php';
    ?>
</body>

</html>