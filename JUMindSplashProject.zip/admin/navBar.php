<nav id="sidebar" class="sidebar">
   <div class="sidebar-content js-simplebar">
      <a class="sidebar-brand" href="index.php">
      <span class="align-middle">JU Mind Splash cms</span>
      </a>
      <ul class="sidebar-nav">

         <li class="sidebar-item active">
            <a data-bs-target="#pages" data-bs-toggle="collapse" class="sidebar-link">
            <i class="align-middle" data-feather="layout"></i> <span class="align-middle">Pages</span>
            </a>
            <ul id="pages" class="sidebar-dropdown list-unstyled collapse show" data-bs-parent="#sidebar">
               <li class="sidebar-item "><a class="sidebar-link" href="Category.php">Category</a></li>
<!--                 <li class="sidebar-item"><a class="sidebar-link" href="AddNewUser.php">Add New User</a></li> -->
<!--                 <li class="sidebar-item"><a class="sidebar-link" href="Form.php">Form</a></li> -->


            </ul>
         </li>
         </ul>
 </div>
</nav>