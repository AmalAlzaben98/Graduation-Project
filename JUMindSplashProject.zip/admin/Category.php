<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Responsive Admin &amp; Dashboard Template based on Bootstrap 5">
	<meta name="author" content="AdminKit">
	<meta name="keywords" content="adminkit, bootstrap, bootstrap 5, admin, dashboard, template, responsive, css, sass, html, theme, front-end, ui kit, web">

	<link rel="preconnect" href="https://fonts.gstatic.com/">
	<link rel="shortcut icon" href="img/icons/icon-48x48.png" />

	<link rel="canonical" href="pages-blank.html" />

	<title>Category | JU Mind Splash</title>

	<link href="css/app.css" rel="stylesheet">


<style>
.float-right{
position: absolute;
    right: 0px;
}
.m-l-20{
	margin-left:30px;
}
.Categoryimage{
	    text-align: center;

}
.rounded-circle {
    border-radius: 25%!important;
}
</style>

</head>
<!--
  HOW TO USE:
  data-theme: default (default), dark, light
  data-layout: fluid (default), boxed
  data-sidebar: left (default), right
-->

<body data-theme="default" data-layout="fluid" data-sidebar="left">
	<div class="wrapper">
	<?php include 'navBar.php'; ?>

		<div class="main">
	<nav class="navbar navbar-expand navbar-light navbar-bg">
				<a class="sidebar-toggle d-flex">
					<i class="hamburger align-self-center"></i>
				</a>



				<div class="navbar-collapse collapse">
					<ul class="navbar-nav navbar-align">



						<li class="nav-item dropdown">
							<a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
								<i class="align-middle" data-feather="settings"></i>
							</a>

							<a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
								<img src="img/avatars/avatar.jpg" class="avatar img-fluid rounded me-1" alt="Charles Hall" /> <span class="text-dark">JU Mind Splash admin</span>
							</a>
							<div class="dropdown-menu dropdown-menu-end">

								<a class="dropdown-item" href="#">Log out</a>
							</div>
						</li>
					</ul>
				</div>
			</nav>
<main class="content">
				<div class="container-fluid p-0">
					<div class="d-flex">
					<h1 class="h3 mb-3">Category</h1>
					<button type="button" class=" float-right btn btn-primary AddnewCategory"  data-bs-toggle="modal" data-bs-target="#defaultModalPrimary">
										Add new Category
									</button>
					</div>


					<div class="row">
						<div class="col-12">

							<div class="card">

								<div class="card-body">
									<table id="datatables-reponsive" class="table table-striped" style="width:100%">
										<thead>
											<tr>
												<th>Name En</th>
												<th>Name Ar</th>
												<th>Image</th>
												<th>Action</th>

											</tr>
										</thead>
										<tbody id="colorTableBody">


										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>
			</main>


		</div>
	</div>
	<div class="updateshow" data-bs-toggle="modal" data-bs-target="#defaultModalPrimary2"></div>
<div class="modal fade" id="defaultModalPrimary" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Add New Category</h5>
													<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
												</div>
												<div class="modal-body m-3">
												<div class="Categoryimage">
														<img id="addImage" src="https://icon-library.com/images/add20image-595b40b85ba036ed117dbead.svg.svg" alt="Christina Mason" class="img-fluid rounded-circle mb-2" width="128" height="128">
														<input type="file" id="file" style="display: none" />
													</div>
												<label class="form-label">Category Name En</label>
													<input id="NEn" class="form-control form-control-lg mb-3" type="text" placeholder="Category Name En">
													<label class="form-label">Category Name Ar</label>
													<input id="NAr" class="form-control form-control-lg mb-3" type="text" placeholder="Category Name Ar">

												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
													<button type="button" class="btn btn-primary Save">Save</button>
												</div>
											</div>
										</div>
									</div>

									<div class="modal fade" id="defaultModalPrimary2" tabindex="-1" role="dialog" aria-hidden="true">
										<div class="modal-dialog" role="document">
											<div class="modal-content">
												<div class="modal-header">
													<h5 class="modal-title">Update Category</h5>
													<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
												</div>
												<div class="modal-body m-3">
												<div class="Categoryimage">
														<img id="addImage2" src="https://icon-library.com/images/add20image-595b40b85ba036ed117dbead.svg.svg" alt="Christina Mason" class="img-fluid rounded-circle mb-2" width="128" height="128">
														<input type="file" id="file" style="display: none" />
													</div>
												<label class="form-label">Category Name En</label>
													<input id="NEn2" class="form-control form-control-lg mb-3" type="text" placeholder="Category Name En">
													<label class="form-label">Category Name Ar</label>
													<input id="NAr2" class="form-control form-control-lg mb-3" type="text" placeholder="Category Name Ar">

												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
													<button type="button" class="btn btn-primary Save2">Save</button>
												</div>
											</div>
										</div>
									</div>
	<script src="js/app.js"></script>
		<script src="js/datatables.js"></script>

<script>
var jsonObj;
var UpdateItemId;
$("#addImage").click(()=>{
	$("#file").click();
});
$("#addImage2").click(()=>{
	$("#file").click();
});
$("#file").change(function(e){
    var file = e.target.files[0];
    var reader = new FileReader();
             reader.readAsDataURL(file); //read base64
    reader.onloadend = function () {
                     // The base64 value of the image
        data_64= reader.result.substring(reader.result.indexOf(",")+1);
        $("#addImage").attr("src",reader.result)
        $("#addImage2").attr("src",reader.result)

            };
});
$(".Save").click(()=>{
	$.ajax({
		  method: "POST",
		  url: "../backend/server.php",
		  data: {
				action   : "addNewCategory",
				CategoryNameEn:$("#NEn").val(),
				CategoryNameAr:$("#NAr").val(),
				CategoryImage: $("#addImage").attr("src")
		  	}

		}).done(function( data ) {
			 var DataRespons = JSON.parse(data);
		        console.log(DataRespons)
				if(DataRespons.status=="success")
					location.reload();
			 });
});
$(".Save2").click(()=>{
	$.ajax({
		  method: "POST",
		  url: "../backend/server.php",
		  data: {
				action   : "UpdateCategory",
				CategoryNameEn:$("#NEn2").val(),
				CategoryNameAr:$("#NAr2").val(),
				CategoryImage: $("#addImage2").attr("src"),
				CategoryID:UpdateItemId,
		  	}

		}).done(function( data ) {
			 var DataRespons = JSON.parse(data);
		        console.log(DataRespons)
				if(DataRespons.status=="success")
					location.reload();
			 });
});


$.ajax({
	  method: "POST",
	  url: "../backend/server.php",
	  data: {
			action   : "getِAllCategory"
	  	}

	}).done(function( data ) {
		  jsonObj = JSON.parse(data);
	        console.log(jsonObj)

	 for(var i = 0; i < jsonObj.length; i++) {
		    var obj = jsonObj[i];


		product='<tr id="CategoryID'+obj.CategoryID+'">'
			+'<td>'+obj.CategoryNameEn+'</td>'
		+'<td>'+obj.CategoryNameAr+'</td>'
		+'<td><img  src="'+obj.CategoryImage+'" alt="Christina Mason" class="img-fluid rounded-circle mb-2" width="128" height="128"></td>'
		+'<td><i class="align-middle me-2 fas fa-fw fa-trash" onclick="deleteItem('+i+')" title="Delete"></i><i onclick="UpdateItem('+i+')" class="align-middle me-2 fas fa-fw fa-edit"></i></td>'

		+'</tr>'

		$('#colorTableBody').append(product);
	 }
	 $("#datatables-reponsive").DataTable({
			responsive: true
		});
	});

function deleteItem(ID){
	var id=jsonObj[ID].CategoryID;
    console.log(id)

	$.ajax({
		  method: "POST",
		  url: "../backend/server.php",
		  data: {
				action   : "deleteSelectCategory",
				CategoryID:id
		  	}

		}).done(function( data ) {

			$("#CategoryID"+id).hide();
			});


}

function UpdateItem(ID){
	UpdateItemId=jsonObj[ID].CategoryID;
	$("#NEn2").val(jsonObj[ID].CategoryNameEn)
	$("#NAr2").val(jsonObj[ID].CategoryNameAr)
	$("#addImage2").attr("src",jsonObj[ID].CategoryImage)

	$(".updateshow").click();
}


	</script>
<script>

</script></body>


</html>